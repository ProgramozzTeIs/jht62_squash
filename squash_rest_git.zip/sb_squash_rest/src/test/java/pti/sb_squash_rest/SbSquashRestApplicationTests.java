package pti.sb_squash_rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbSquashRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
