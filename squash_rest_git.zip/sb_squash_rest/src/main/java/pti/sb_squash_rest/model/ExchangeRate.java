package pti.sb_squash_rest.model;



public class ExchangeRate {
	
	private String curreny;
	private double exchangeRate;
	
	public ExchangeRate(String curreny, double exchangeRate) {
		super();
		
		this.curreny = curreny;
		this.exchangeRate = exchangeRate;
	}

	public String getCurreny() {
		return curreny;
	}

	public void setCurreny(String curreny) {
		this.curreny = curreny;
	}

	public double getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(double exchangeRate) {
		this.exchangeRate = exchangeRate;
	}
	
	
	
	

}
