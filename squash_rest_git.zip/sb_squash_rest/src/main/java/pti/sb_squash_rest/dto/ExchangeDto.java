package pti.sb_squash_rest.dto;

public class ExchangeDto {
	
	private double convertedAmount;

	public ExchangeDto(double convertedAmount) {
		super();
		this.convertedAmount = convertedAmount;
	}

	public double getConvertedAmount() {
		return convertedAmount;
	}

	public void setConvertedAmount(double convertedAmount) {
		this.convertedAmount = convertedAmount;
	}
	
	

}
