package pti.sb_squash_rest.xml;

import java.io.IOException;
import java.io.StringReader;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.springframework.stereotype.Repository;

import pti.sb_squash_rest.model.ExchangeRate;

@Repository
public class XmlParser {

	public ExchangeRate getRate(String xmlResponse) throws JDOMException, IOException {
		
		ExchangeRate exchangeRate = null;
		
		SAXBuilder sb = new SAXBuilder();
		Document document = sb.build(new StringReader(xmlResponse));
		
		Element rootElement = document.getRootElement();
		Element rateElement = rootElement.getChild("deviza");
		Element itemElement = rateElement.getChild("item");
		
		String date = itemElement.getChildText("datum");
		String currency = itemElement.getChildText("penznem");
		String rate = itemElement.getChildText("kozep");
		
		exchangeRate = new ExchangeRate(
				currency,
				Double.parseDouble(rate));
		
		
		return exchangeRate;
		
	}

}
