package pti.sb_squash_rest.controller;

import java.io.IOException;
import java.time.LocalDateTime;

import org.jdom2.JDOMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import pti.sb_squash_rest.dto.ExchangeDto;
import pti.sb_squash_rest.service.AppService;

@RestController
public class AppController {
	
	private AppService service;

	@Autowired
	public AppController(AppService service) {
		super();
		this.service = service;
	}
	
	@GetMapping("/convert")
	public ExchangeDto getRate(
			@RequestParam("date") String date,
			@RequestParam("amount") int amount) throws JDOMException, IOException {
		
		ExchangeDto exchangeDto = service.getRate(date, amount);
		
		return exchangeDto;
	}
	

}
