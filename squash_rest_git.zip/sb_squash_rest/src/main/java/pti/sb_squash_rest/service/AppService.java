package pti.sb_squash_rest.service;

import java.io.IOException;


import org.jdom2.JDOMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import pti.sb_squash_rest.dto.ExchangeDto;
import pti.sb_squash_rest.model.ExchangeRate;
import pti.sb_squash_rest.xml.XmlParser;

@Service
public class AppService {
	
	private XmlParser parser;
	
	@Autowired
	public AppService(XmlParser parser) {
		super();
		this.parser = parser;
	}

	public ExchangeDto getRate(String date, int amount) throws JDOMException, IOException {
		
		ExchangeDto exchangeDto = null;
		
		RestTemplate rt = new RestTemplate();
		String xmlResponse = rt.getForObject("http://api.napiarfolyam.hu/?bank=mnb&valuta=eur&datum=" + date, String.class);
		
		ExchangeRate exchangeRate = parser.getRate(xmlResponse);
		
		double convertedAmount = amount / exchangeRate.getExchangeRate();
		
		exchangeDto = new ExchangeDto(convertedAmount);
		
		
		
		return exchangeDto;
	}

}
